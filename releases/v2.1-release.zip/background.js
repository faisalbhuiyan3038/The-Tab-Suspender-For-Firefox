// State management
let SUSPEND_TIME = 40 * 60 * 1000;
let isEnabled = true; // Enabled by default
let activeTabId = null;
let suspendedTabs = {};
let tabTimers = {};
let discardTimers = {};  // Track re-discard timers for suspended tabs
let settings = {
  ignoreAudio: true,
  ignoreFormInput: true,
  ignoreNotifications: true,
  ignorePinned: true,
  enableScreenshots: false,
  captureQuality: 50,
  resizeWidth: 1280,
  resizeHeight: 720,
  resizeQuality: 0.5,
  whitelistedDomains: [],
  whitelistedUrls: [],
  autoDiscard: true,       // Enable auto-discard after suspension
  rediscardDelay: 30,      // Seconds to wait before re-discarding a suspended tab
  pauseUntil: 0,
  directDiscard: false,
  suspendEmoji: 'none',
  siteSettings: {}         // Site-specific settings overrides
};
let pauseExpirationTimer = null;

// --- Storage Management ---

const SYNC_SETTINGS_KEYS = [
  'suspendTime',
  'isEnabled',
  'ignoreAudio',
  'ignoreFormInput',
  'ignoreNotifications',
  'ignorePinned',
  'whitelistedDomains',
  'whitelistedUrls',
  'enableScreenshots',
  'captureQuality',
  'resizeWidth',
  'resizeHeight',
  'resizeQuality',
  'autoDiscard',
  'rediscardDelay',
  'pauseUntil',
  'directDiscard',
  'suspendEmoji',
  'siteSettings'
];

async function loadSettings() {
  try {
    const result = await browser.storage.sync.get(SYNC_SETTINGS_KEYS);

    if (result.suspendTime) {
      SUSPEND_TIME = result.suspendTime * 60 * 1000;
    }
    if (result.isEnabled !== undefined) {
      isEnabled = result.isEnabled;
    }
    settings = {
      suspendTime: result.suspendTime || 40,
      ignoreAudio: result.ignoreAudio ?? true,
      ignoreFormInput: result.ignoreFormInput ?? true,
      ignoreNotifications: result.ignoreNotifications ?? true,
      ignorePinned: result.ignorePinned ?? true,
      enableScreenshots: result.enableScreenshots ?? false,
      captureQuality: result.captureQuality || 50,
      resizeWidth: result.resizeWidth || 1280,
      resizeHeight: result.resizeHeight || 720,
      resizeQuality: result.resizeQuality || 0.5,
      whitelistedDomains: result.whitelistedDomains ?? [],
      whitelistedUrls: result.whitelistedUrls ?? [],
      autoDiscard: result.autoDiscard ?? true,
      rediscardDelay: result.rediscardDelay ?? 30,
      pauseUntil: result.pauseUntil ?? 0,
      directDiscard: result.directDiscard ?? false,
      suspendEmoji: result.suspendEmoji ?? 'none',
      siteSettings: result.siteSettings ?? {}
    };

    console.log('Settings loaded/reloaded:', settings, `Suspend Time: ${SUSPEND_TIME}`);

    // Schedule resume if paused
    if (pauseExpirationTimer) {
      clearTimeout(pauseExpirationTimer);
      pauseExpirationTimer = null;
    }

    if (settings.pauseUntil > Date.now()) {
      const waitTime = settings.pauseUntil - Date.now();
      console.log(`Scheduling pause expiration in ${waitTime}ms`);
      pauseExpirationTimer = setTimeout(() => {
        console.log('Pause expired. Re-initializing tab timers.');
        settings.pauseUntil = 0;
        browser.storage.sync.set({ pauseUntil: 0 });
        initializeTimers();
      }, waitTime);
    } else if (settings.pauseUntil !== 0) {
      // If we loaded settings and the pause is already historically over, fix it
      settings.pauseUntil = 0;
      browser.storage.sync.set({ pauseUntil: 0 });
    }

  } catch (error) {
    console.error('Error loading settings:', error);
  }
}

async function loadSuspendedTabs() {
  try {
    const result = await browser.storage.local.get('suspendedTabs');
    if (result.suspendedTabs) {
      suspendedTabs = result.suspendedTabs;
    }
  } catch (error) {
    console.error('Error loading suspended tabs:', error);
  }
}

/**
 * Removes suspendedTabs entries for tabs that no longer exist.
 * This handles edge cases like browser crashes, extension updates where recovery failed, etc.
 */
async function cleanupOrphanedEntries() {
  try {
    const tabs = await browser.tabs.query({});
    const existingTabIds = new Set(tabs.map(t => t.id));

    let orphansRemoved = 0;
    const orphanThumbnails = [];

    for (const tabIdStr of Object.keys(suspendedTabs)) {
      const tabId = parseInt(tabIdStr, 10);
      if (!existingTabIds.has(tabId)) {
        // This tab no longer exists - check if the tab at least shows our suspended page
        // (which would mean it's a valid suspended tab)
        const matchingTab = tabs.find(t => {
          if (t.url && t.url.startsWith(browser.runtime.getURL("suspended.html"))) {
            try { return new URL(t.url).searchParams.get("tabId") === tabIdStr; } catch (e) {}
          }
          return false;
        });

        if (matchingTab) {
          console.log(`Migrating tab data from ${tabIdStr} to ${matchingTab.id}`);
          suspendedTabs[matchingTab.id] = suspendedTabs[tabIdStr];
          delete suspendedTabs[tabIdStr];
          
          const oldThumb = "thumbnail_" + tabIdStr;
          const newThumb = "thumbnail_" + matchingTab.id;
          const oldTemp = "temp_img_" + tabIdStr;
          const newTemp = "temp_img_" + matchingTab.id;
          
          browser.storage.local.get([oldThumb, oldTemp]).then(data => {
            const toSet = {};
            if (data[oldThumb]) toSet[newThumb] = data[oldThumb];
            if (data[oldTemp]) toSet[newTemp] = data[oldTemp];
            if (Object.keys(toSet).length > 0) browser.storage.local.set(toSet);
          });
          
          orphanThumbnails.push(oldThumb, oldTemp);
          orphansRemoved++; // Trigger cleanup save processing
          
          try {
            const urlObj = new URL(matchingTab.url);
            urlObj.searchParams.set("tabId", matchingTab.id);
            browser.tabs.update(matchingTab.id, { url: urlObj.toString() });
          } catch (e) {}
        } else {
          console.log(`Cleanup: Removing orphaned entry for non-existent tab ${tabId}`);
          delete suspendedTabs[tabIdStr];
          orphanThumbnails.push("thumbnail_" + tabId, "temp_img_" + tabId);
          orphansRemoved++;
        }
      }
    }

    if (orphansRemoved > 0) {
      saveSuspendedTabsState();
      if (orphanThumbnails.length > 0) {
        await browser.storage.local.remove(orphanThumbnails);
      }
      console.log(`Cleanup: Removed ${orphansRemoved} orphaned entries from storage.`);
    }
  } catch (error) {
    console.error('Error during orphan cleanup:', error);
  }
}

async function initialize() {
  await loadSettings();
  // Only load from storage if suspendedTabs wasn't already populated (e.g., by recoverSuspendedTabs)
  if (Object.keys(suspendedTabs).length === 0) {
    await loadSuspendedTabs();
  }
  // Clean up any orphaned entries (from crashes, failed recoveries, etc.)
  await cleanupOrphanedEntries();
  initializeTimers();
}

// --- Tab Timer Logic ---

/**
 * Resets (or creates) the suspension timer for a given tab.
 */
async function resetTabTimer(tabId) {
  if (tabTimers[tabId]) {
    clearTimeout(tabTimers[tabId]);
    delete tabTimers[tabId];
  }

  try {
    const tab = await browser.tabs.get(tabId);

    if (tab.url.startsWith(browser.runtime.getURL("suspended.html"))) {
      return;
    }

    if (isEnabled && tabId !== activeTabId) {
      if (tabTimers[tabId]) {
        clearTimeout(tabTimers[tabId]);
      }

      const tabSettings = getTabSettings(tab);
      const suspendTimeMs = tabSettings.suspendTime * 60 * 1000;

      tabTimers[tabId] = setTimeout(() => {
        suspendTab(tabId);
      }, suspendTimeMs);
    }
  } catch (error) {
    console.error(`Error in resetTabTimer for tab ${tabId}:`, error);
  }
}

/**
 * Suspends the tab by saving its original URL and updating it
 * to a local suspended page.
 * @param {number} tabId - The ID of the tab to suspend
 * @param {boolean} [force=false] - If true, will suspend even if the tab is active
 */
async function suspendTab(tabId, force = false) {
  if (!force && tabId === activeTabId) {
    return;
  }

  try {
    const tab = await browser.tabs.get(tabId);

    if (tab.url.startsWith(browser.runtime.getURL("suspended.html"))) {
      return;
    }

    const shouldProtect = await shouldProtectTab(tab, force);
    if (shouldProtect) {
      console.log(`Tab ${tabId} is protected, not suspending`);
      return;
    }

    const tabSettings = getTabSettings(tab);
    if (tabSettings.directDiscard && !tab.active) {
      try {
        if (settings.suspendEmoji && settings.suspendEmoji !== 'none') {
          try {
            await browser.tabs.executeScript(tabId, {
              code: `if (!document.title.startsWith('${settings.suspendEmoji} ')) { document.title = '${settings.suspendEmoji} ' + document.title; }`
            });
            // Brief delay to allow the title change to register in the browser UI before discarding
            await new Promise(r => setTimeout(r, 100));
          } catch (scriptErr) {
            console.log('Could not inject title script (may be a protected or discarded page).', scriptErr);
          }
        }
        await browser.tabs.discard(tabId);
        console.log(`Native discarded tab ${tabId}`);
        return true;
      } catch (e) {
        console.error('Error with native discard, falling back to suspended page:', e);
        // Fall through to custom suspended page logic
      }
    }

    suspendedTabs[tabId] = {
      url: tab.url,
      title: tab.title,
      favIconUrl: tab.favIconUrl,
    };

    saveSuspendedTabsState();

    let suspendedPageURL = browser.runtime.getURL("suspended.html") +
      "?origUrl=" + encodeURIComponent(tab.url) +
      "&title=" + encodeURIComponent(tab.title) +
      "&favIconUrl=" + encodeURIComponent(tab.favIconUrl || '') +
      "&tabId=" + tabId;

    if (settings.enableScreenshots) {
      try {
        const fullResImage = await browser.tabs.captureTab(tabId, {
          format: "jpeg",
          quality: settings.captureQuality
        });

        await browser.storage.local.set({ ["temp_img_" + tabId]: fullResImage });
        suspendedPageURL += "&hasCapture=true";
        console.log(`Captured screenshot for tab ${tabId}`);
      } catch (captureError) {
        console.error(`Failed to capture tab ${tabId}:`, captureError);
      }
    }

    browser.tabs.update(tabId, { url: suspendedPageURL });

    // Auto-discard the tab after suspension to free memory
    if (settings.autoDiscard) {
      setTimeout(async () => {
        try {
          await browser.tabs.discard(tabId);
          console.log(`Discarded suspended tab ${tabId}`);
        } catch (e) {
          // Tab might be active or already closed - this is expected
        }
      }, 1500);
    }

    return true;
  } catch (e) {
    console.error('Error suspending tab:', e);
    return false;
  }
}

// --- Event Listeners (Tabs, Windows) ---
browser.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete') {
    if (!tab.url.startsWith(browser.runtime.getURL("suspended.html"))) {
      if (tabId !== activeTabId) {
        resetTabTimer(tabId);
      }
    }
  }

  if (changeInfo.status === 'complete' && suspendedTabs[tabId]) {
    const originalTab = suspendedTabs[tabId];

    if (tab.url === originalTab.url) {
      // Logic to re-suspend a tab that was navigated "back" to
      let suspendedPageURL = browser.runtime.getURL("suspended.html") +
        "?origUrl=" + encodeURIComponent(originalTab.url) +
        "&title=" + encodeURIComponent(originalTab.title) +
        "&favIconUrl=" + encodeURIComponent(originalTab.favIconUrl || '') +
        "&tabId=" + tabId;

      browser.tabs.update(tabId, { url: suspendedPageURL });
    }
  }
});

browser.tabs.onActivated.addListener((activeInfo) => {
  const previousActiveTab = activeTabId;
  activeTabId = activeInfo.tabId;

  // Clear suspension timer for newly active tab
  if (tabTimers[activeTabId]) {
    clearTimeout(tabTimers[activeTabId]);
    delete tabTimers[activeTabId];
  }

  // Clear any pending re-discard timer for the newly active tab
  if (discardTimers[activeTabId]) {
    clearTimeout(discardTimers[activeTabId]);
    delete discardTimers[activeTabId];
  }

  if (previousActiveTab && previousActiveTab !== activeTabId) {
    browser.tabs.get(previousActiveTab).then(tab => {
      const isSuspendedPage = tab.url.startsWith(browser.runtime.getURL("suspended.html"));

      if (isSuspendedPage && settings.autoDiscard) {
        // Previous tab was a suspended page that wasn't restored
        // Start a re-discard timer
        if (discardTimers[previousActiveTab]) {
          clearTimeout(discardTimers[previousActiveTab]);
        }
        discardTimers[previousActiveTab] = setTimeout(async () => {
          try {
            await browser.tabs.discard(previousActiveTab);
            console.log(`Re-discarded suspended tab ${previousActiveTab} after inactivity`);
          } catch (e) {
            // Tab might be closed or active again
          }
          delete discardTimers[previousActiveTab];
        }, settings.rediscardDelay * 1000);
      } else if (!isSuspendedPage) {
        // Normal tab - start suspension timer
        resetTabTimer(previousActiveTab);
      }
    }).catch(() => { /* Tab might be closed */ });
  }
});

browser.windows.onFocusChanged.addListener((windowId) => {
  if (windowId === browser.windows.WINDOW_ID_NONE) return;

  browser.tabs.query({ active: true, windowId }).then(tabs => {
    if (tabs[0]) {
      const previousActiveTab = activeTabId;
      activeTabId = tabs[0].id;

      // Clear suspension timer for newly active tab
      if (tabTimers[activeTabId]) {
        clearTimeout(tabTimers[activeTabId]);
        delete tabTimers[activeTabId];
      }

      // Clear any pending re-discard timer for the newly active tab
      if (discardTimers[activeTabId]) {
        clearTimeout(discardTimers[activeTabId]);
        delete discardTimers[activeTabId];
      }

      if (previousActiveTab && previousActiveTab !== activeTabId) {
        browser.tabs.get(previousActiveTab).then(tab => {
          const isSuspendedPage = tab.url.startsWith(browser.runtime.getURL("suspended.html"));

          if (isSuspendedPage && settings.autoDiscard) {
            // Previous tab was a suspended page that wasn't restored
            // Start a re-discard timer
            if (discardTimers[previousActiveTab]) {
              clearTimeout(discardTimers[previousActiveTab]);
            }
            discardTimers[previousActiveTab] = setTimeout(async () => {
              try {
                await browser.tabs.discard(previousActiveTab);
                console.log(`Re-discarded suspended tab ${previousActiveTab} after window focus change`);
              } catch (e) {
                // Tab might be closed or active again
              }
              delete discardTimers[previousActiveTab];
            }, settings.rediscardDelay * 1000);
          } else if (!isSuspendedPage) {
            // Normal tab - start suspension timer
            resetTabTimer(previousActiveTab);
          }
        }).catch(() => { /* Tab might be closed */ });
      }
    }
  });
});

// --- Event Listeners (Runtime, Storage) ---
browser.runtime.onMessage.addListener(async (message, sender) => {
  if (message.action === 'updateTheme') {
    browser.tabs.query({}).then(tabs => {
      tabs.forEach(tab => {
        if (suspendedTabs[tab.id]) {
          browser.tabs.sendMessage(tab.id, {
            action: 'updateTheme',
            isDark: message.isDark
          });
        }
      });
    });
    return;
  }
  if (message.action === "resumeTab" && sender.tab) {
    const origUrl = message.origUrl;
    const tabId = sender.tab.id;

    // Clear any pending re-discard timer
    if (discardTimers[tabId]) {
      clearTimeout(discardTimers[tabId]);
      delete discardTimers[tabId];
    }

    if (suspendedTabs[tabId]) {
      delete suspendedTabs[tabId];
      saveSuspendedTabsState();
    }
    await browser.storage.local.remove([
      "thumbnail_" + tabId,
      "temp_img_" + tabId
    ]);
    browser.tabs.update(tabId, { url: origUrl });
  }
});

browser.storage.onChanged.addListener((changes, areaName) => {
  if (areaName === 'sync') {
    const settingsChanged = SYNC_SETTINGS_KEYS.some(key => changes.hasOwnProperty(key));

    if (settingsChanged) {
      console.log('Sync settings changed, reloading...');
      loadSettings().then(() => {
        Object.keys(tabTimers).forEach(tabId => {
          resetTabTimer(parseInt(tabId, 10));
        });
      });
    }
  }
});

function initializeTimers() {
  browser.tabs.query({}).then(tabs => {
    const activeTab = tabs.find(tab => tab.active);
    if (activeTab) {
      activeTabId = activeTab.id;
    }

    tabs.forEach(tab => {
      // Do not reset timer if paused
      if (settings.pauseUntil > Date.now()) {
        if (tabTimers[tab.id]) {
          clearTimeout(tabTimers[tab.id]);
          delete tabTimers[tab.id];
        }
        return;
      }
      if (!tab.active && !tab.url.startsWith(browser.runtime.getURL("suspended.html"))) {
        resetTabTimer(tab.id);
      }
    });
  });
}

async function toggleSiteOverrideForTab(tab) {
  if (!tab || !tab.url || !tab.url.match(/^https?:\/\//)) {
    return;
  }

  try {
    const domain = new URL(tab.url).hostname;
    const newSiteSettings = { ...settings.siteSettings };
    let message = '';

    if (newSiteSettings[domain]) {
      delete newSiteSettings[domain];
      message = `Custom settings disabled for ${domain}`;
    } else {
      newSiteSettings[domain] = {
        ignoreAudio: settings.ignoreAudio,
        ignoreFormInput: settings.ignoreFormInput,
        ignoreNotifications: settings.ignoreNotifications,
        ignorePinned: settings.ignorePinned,
        directDiscard: settings.directDiscard,
        suspendTime: settings.suspendTime || 40
      };
      message = `Custom settings enabled for ${domain}`;
    }

    await browser.storage.sync.set({ siteSettings: newSiteSettings });
    console.log(message);

    try {
      browser.notifications.create({
        type: 'basic',
        iconUrl: browser.runtime.getURL('icons/icon48.png'),
        title: 'Tab Suspender',
        message: message
      });
    } catch (notifErr) {
      console.error('Failed to show notification:', notifErr);
    }
  } catch (error) {
    console.error('Error toggling site override:', error);
  }
}

browser.contextMenus.create({
  id: 'whitelistDomain',
  title: 'Whitelist this domain',
  contexts: ['page']
});
browser.contextMenus.create({
  id: 'whitelistUrl',
  title: 'Whitelist this page',
  contexts: ['page']
});
browser.contextMenus.create({
  id: 'toggleSiteOverride',
  title: chrome.i18n.getMessage('toggleSiteOverride') || 'Toggle custom settings override for this site',
  contexts: ['page']
});
browser.contextMenus.create({
  id: 'suspendPage',
  title: 'Suspend This Page',
  contexts: ['page']
});

browser.contextMenus.onClicked.addListener(async (info, tab) => {
  try {
    if (info.menuItemId === 'whitelistDomain') {
      const url = new URL(tab.url);
      const domain = url.hostname;
      if (!settings.whitelistedDomains.includes(domain)) {
        const newDomains = [...settings.whitelistedDomains, domain];
        await browser.storage.sync.set({ whitelistedDomains: newDomains });
      }
    } else if (info.menuItemId === 'whitelistUrl') {
      const pageUrl = tab.url;
      if (!settings.whitelistedUrls.includes(pageUrl)) {
        const newUrls = [...settings.whitelistedUrls, pageUrl];
        await browser.storage.sync.set({ whitelistedUrls: newUrls });
      }
    } else if (info.menuItemId === 'toggleSiteOverride') {
      await toggleSiteOverrideForTab(tab);
    } else if (info.menuItemId === 'suspendPage') {
      const success = await suspendTab(tab.id, true);
      if (success) {
        // Tab suspended successfully
      }
    }
  } catch (error) {
    console.error('Error in context menu action:', error);
  }
});

// --- Protection Logic ---
function getTabSettings(tab) {
  let domain = '';
  if (tab && tab.url) {
    try {
      domain = new URL(tab.url).hostname;
    } catch (e) {
      // Ignore
    }
  }

  const siteConfig = domain && settings.siteSettings && settings.siteSettings[domain];
  if (siteConfig) {
    return {
      ignoreAudio: siteConfig.ignoreAudio ?? settings.ignoreAudio,
      ignoreFormInput: siteConfig.ignoreFormInput ?? settings.ignoreFormInput,
      ignoreNotifications: siteConfig.ignoreNotifications ?? settings.ignoreNotifications,
      ignorePinned: siteConfig.ignorePinned ?? settings.ignorePinned,
      directDiscard: siteConfig.directDiscard ?? settings.directDiscard,
      suspendTime: siteConfig.suspendTime !== undefined ? siteConfig.suspendTime : (settings.suspendTime || 40)
    };
  }

  return {
    ignoreAudio: settings.ignoreAudio,
    ignoreFormInput: settings.ignoreFormInput,
    ignoreNotifications: settings.ignoreNotifications,
    ignorePinned: settings.ignorePinned,
    directDiscard: settings.directDiscard,
    suspendTime: settings.suspendTime || 40
  };
}

async function shouldProtectTab(tab, force = false) {
  // Check for non-http(s) pages (like about:, moz-extension:, etc.)
  if (!tab.url.match(/^https?:\/\//)) {
    return true;
  }

  if (force) {
    return false;
  }

  // Check if suspension is paused globally
  if (settings.pauseUntil > Date.now()) {
    return true;
  }

  const tabSettings = getTabSettings(tab);

  // Check for pinned tabs
  if (tabSettings.ignorePinned && tab.pinned) {
    return true;
  }

  try {
    // Check whitelist
    try {
      const url = new URL(tab.url);
      if (settings.whitelistedDomains.includes(url.hostname)) {
        return true;
      }
      if (settings.whitelistedUrls.includes(tab.url)) {
        return true;
      }
    } catch (error) {
      console.error('Error checking whitelist:', error);
    }

    // Check for audio
    if (tabSettings.ignoreAudio && tab.audible) {
      return true;
    }

    // Check for form changes and notifications
    try {
      const results = await browser.tabs.executeScript(tab.id, {
        code: `
          {
            const formProtection = ${tabSettings.ignoreFormInput} && (() => {
              const inputs = document.querySelectorAll('input, textarea, select');
              return Array.from(inputs).some(input => {
                const tagName = input.tagName.toUpperCase();
                const type = (input.type || '').toLowerCase();
                const ignoredTypes = ['hidden', 'button', 'submit', 'reset', 'image'];
                if (tagName === 'INPUT' && ignoredTypes.includes(type)) {
                  return false;
                }
                if (tagName === 'INPUT' && (type === 'checkbox' || type === 'radio')) {
                  return input.checked !== input.defaultChecked;
                }
                if (tagName === 'SELECT') {
                  if (input.multiple) {
                    return Array.from(input.options).some(opt => opt.selected !== opt.defaultSelected);
                  } else {
                    let defaultSelectedIndex = -1;
                    for (let i = 0; i < input.options.length; i++) {
                      if (input.options[i].defaultSelected) {
                        defaultSelectedIndex = i;
                        break;
                      }
                    }
                    if (defaultSelectedIndex === -1 && input.options.length > 0) {
                      defaultSelectedIndex = 0;
                    }
                    return input.selectedIndex !== defaultSelectedIndex;
                  }
                }
                return input.value !== input.defaultValue;
              });
            })();
            const notificationProtection = ${tabSettings.ignoreNotifications} &&
              'Notification' in window &&
              Notification.permission === 'granted';
            ({ formProtection, notificationProtection })
          }
        `
      });

      const { formProtection, notificationProtection } = results[0];
      if (formProtection) return true;
      if (notificationProtection) return true;

    } catch (error) {
      // Can't execute script (e.g., on some protected pages)
      return true;
    }

    return false;

  } catch (e) {
    return true;
  }
}

// --- Utility Functions ---
function saveSuspendedTabsState() {
  browser.storage.local.set({ suspendedTabs });
}

browser.tabs.onRemoved.addListener(async (tabId) => {
  // Clear any pending discard timer
  if (discardTimers[tabId]) {
    clearTimeout(discardTimers[tabId]);
    delete discardTimers[tabId];
  }

  if (suspendedTabs[tabId]) {
    delete suspendedTabs[tabId];
    saveSuspendedTabsState();
  }
  // Clean up all associated storage
  await browser.storage.local.remove([
    "thumbnail_" + tabId,
    "temp_img_" + tabId
  ]);
});

browser.runtime.onStartup.addListener(() => {
  browser.tabs.query({}).then(tabs => {
    tabs.forEach(tab => {
      if (suspendedTabs[tab.id] && suspendedTabs[tab.id].url === tab.url) {
        const originalTab = suspendedTabs[tab.id];
        const suspendedPageURL = browser.runtime.getURL("suspended.html") +
          "?origUrl=" + encodeURIComponent(originalTab.url) +
          "&title=" + encodeURIComponent(originalTab.title) +
          "&favIconUrl=" + encodeURIComponent(originalTab.favIconUrl || '') +
          "&tabId=" + tab.id; // Always include tabId
        browser.tabs.update(tab.id, { url: suspendedPageURL });
      }
    });
  });
});


browser.commands.onCommand.addListener(async (commandName) => {
  const tabs = await browser.tabs.query({ active: true, currentWindow: true });
  if (tabs.length === 0) return;
  const tab = tabs[0];

  switch (commandName) {
    case "suspend-current-tab": {
      const success = await suspendTab(tab.id, true); // Force suspend
      if (success) {
        // Tab suspended successfully
      }
      break;
    }

    case "whitelist-current-page": {
      try {
        const pageUrl = tab.url;
        if (!settings.whitelistedUrls.includes(pageUrl)) {
          const newUrls = [...settings.whitelistedUrls, pageUrl];
          settings.whitelistedUrls = newUrls;
          await browser.storage.sync.set({ whitelistedUrls: newUrls });
        }
      } catch (error) {
        console.error('Error whitelisting page:', error);
      }
      break;
    }

    case "unsuspend-current-tab": {
      // Clear any pending re-discard timer
      if (discardTimers[tab.id]) {
        clearTimeout(discardTimers[tab.id]);
        delete discardTimers[tab.id];
      }

      if (suspendedTabs[tab.id]) {
        const origUrl = suspendedTabs[tab.id].url;
        delete suspendedTabs[tab.id];
        saveSuspendedTabsState();
        await browser.storage.local.remove([
          "thumbnail_" + tab.id,
          "temp_img_" + tab.id
        ]);
        await browser.tabs.update(tab.id, { url: origUrl });
      }
      break;
    }

    case "toggle-site-override": {
      await toggleSiteOverrideForTab(tab);
      break;
    }
  }
});

/**
 * Moves settings from browser.storage.local to browser.storage.sync
 * AND migrates local tab storage to new format
 */
async function runMigration() {
  // 1. Migrate SYNC settings
  const keysToMigrate = [
    'suspendTime',
    'isEnabled',
    'ignoreAudio',
    'ignoreFormInput',
    'ignoreNotifications',
    'ignorePinned',
    'whitelistedDomains',
    'whitelistedUrls'
  ];

  try {
    const localData = await browser.storage.local.get(keysToMigrate);
    if (Object.keys(localData).length > 0) {
      console.log("Migration: Found old settings in local storage. Migrating to sync...");
      let settingsToSync = {};
      for (const key of keysToMigrate) {
        if (localData[key] !== undefined) {
          settingsToSync[key] = localData[key];
        }
      }
      if (Object.keys(settingsToSync).length > 0) {
        await browser.storage.sync.set(settingsToSync);
        console.log("Migration: Successfully moved settings to sync storage.", settingsToSync);
        await browser.storage.local.remove(keysToMigrate);
        console.log("Migration: Cleaned up old settings from local storage.");
      }
    } else {
      console.log("Migration check: No local settings found to migrate.");
    }
  } catch (error) {
    console.error("Sync Migration failed:", error);
  }

  //  Migrate LOCAL tab storage
  try {
    const oldStorage = await browser.storage.local.get("suspendedTabs");
    if (oldStorage.suspendedTabs) {
      console.log("Migration: Found old 'suspendedTabs' blob. Migrating to new format...");
      const oldTabs = oldStorage.suspendedTabs;
      let newSuspendedTabs = {};
      let newThumbnails = {};

      for (const [tabId, data] of Object.entries(oldTabs)) {
        if (data && data.url) { // Check if data is valid
          const { thumbnail, ...rest } = data;
          newSuspendedTabs[tabId] = rest; // Add text data to new blob
          if (thumbnail) {
            newThumbnails["thumbnail_" + tabId] = thumbnail; // Add thumbnail to its own key
          }
        }
      }

      if (Object.keys(newThumbnails).length > 0) {
        await browser.storage.local.set(newThumbnails);
        console.log(`Migration: Migrated ${Object.keys(newThumbnails).length} thumbnails.`);
      }

      await browser.storage.local.set({ suspendedTabs: newSuspendedTabs });
      console.log("Migration: New text-only 'suspendedTabs' saved. Migration complete.");

      // Update in-memory object
      suspendedTabs = newSuspendedTabs;

    } else {
      console.log("Migration check: No old 'suspendedTabs' blob found. No local data migration needed.");
    }
  } catch (error) {
    console.error("Local Tab Storage Migration failed:", error);
  }
}

/**
 * Recovers suspended tabs after addon update.
 * 
 * Strategy:
 * 1. First, try to find existing tabs showing old extension URLs (works for about:debugging reloads)
 * 2. If no tabs found but we have data in suspendedTabs (from migration), re-create the tabs
 * 
 * Firefox closes/invalidates extension pages when an extension is updated,
 * so we need to re-create the tabs from our stored data.
 */
async function recoverSuspendedTabs() {
  try {
    const currentBase = browser.runtime.getURL("suspended.html");
    console.log("Current extension base:", currentBase);

    // Step 1: Try to find any existing suspended tabs (may work for about:debugging)
    const suspendedPagePattern = /^moz-extension:\/\/[^/]+\/suspended\.html\?/;
    const tabs = await browser.tabs.query({});
    console.log(`Found ${tabs.length} total tabs. Checking for suspended pages...`);

    let recoveredFromTabs = 0;

    for (const tab of tabs) {
      console.log(`Tab ${tab.id}: ${tab.url?.substring(0, 100)}...`);

      if (tab.url && suspendedPagePattern.test(tab.url)) {
        console.log(`Found existing suspended tab ${tab.id}`);
        try {
          const url = new URL(tab.url);
          const origUrl = url.searchParams.get('origUrl');
          const title = url.searchParams.get('title');
          const favIconUrl = url.searchParams.get('favIconUrl');

          if (origUrl) {
            suspendedTabs[tab.id] = {
              url: decodeURIComponent(origUrl),
              title: decodeURIComponent(title || ''),
              favIconUrl: decodeURIComponent(favIconUrl || '')
            };
            recoveredFromTabs++;

            // Navigate to the NEW extension's suspended.html URL
            const newSuspendedURL = currentBase +
              "?origUrl=" + encodeURIComponent(suspendedTabs[tab.id].url) +
              "&title=" + encodeURIComponent(suspendedTabs[tab.id].title) +
              "&favIconUrl=" + encodeURIComponent(suspendedTabs[tab.id].favIconUrl) +
              "&tabId=" + tab.id;

            await browser.tabs.update(tab.id, { url: newSuspendedURL });
            console.log(`Updated tab ${tab.id} to new extension URL`);
          }
        } catch (parseError) {
          console.error(`Failed to parse suspended tab URL for tab ${tab.id}:`, parseError);
        }
      }
    }

    if (recoveredFromTabs > 0) {
      saveSuspendedTabsState();
      console.log(`Recovered ${recoveredFromTabs} suspended tabs from existing browser tabs.`);
      return;
    }

    // Step 2: No existing tabs found - check if we have stored data to restore from
    // The suspendedTabs object may have been populated by runMigration() earlier
    const storedTabsCount = Object.keys(suspendedTabs).length;

    if (storedTabsCount === 0) {
      console.log("No suspended tabs found to recover (none in tabs, none in storage).");
      return;
    }

    console.log(`No browser tabs found, but have ${storedTabsCount} entries in storage. Re-creating tabs...`);

    // Re-create tabs from storage
    // We need to create new tabs and update our suspendedTabs with new IDs
    const oldEntries = Object.entries(suspendedTabs);
    const newSuspendedTabs = {};

    for (const [oldTabId, data] of oldEntries) {
      if (!data || !data.url) continue;

      try {
        // Create the suspended page URL
        const suspendedURL = currentBase +
          "?origUrl=" + encodeURIComponent(data.url) +
          "&title=" + encodeURIComponent(data.title || '') +
          "&favIconUrl=" + encodeURIComponent(data.favIconUrl || '');

        // Create a new tab with the suspended page
        // Note: We'll add tabId param after we know the new tab's ID
        const newTab = await browser.tabs.create({
          url: suspendedURL,
          active: false  // Don't activate - keep them suspended in background
        });

        // Update the URL to include the correct tabId
        const finalURL = suspendedURL + "&tabId=" + newTab.id;
        await browser.tabs.update(newTab.id, { url: finalURL });

        // Register with new tab ID
        newSuspendedTabs[newTab.id] = {
          url: data.url,
          title: data.title || '',
          favIconUrl: data.favIconUrl || ''
        };

        console.log(`Re-created suspended tab: old ID ${oldTabId} -> new ID ${newTab.id}: ${data.url}`);

        // Try to migrate thumbnail if it exists
        try {
          const thumbKey = "thumbnail_" + oldTabId;
          const thumbData = await browser.storage.local.get(thumbKey);
          if (thumbData[thumbKey]) {
            // Save with new tab ID
            await browser.storage.local.set({ ["thumbnail_" + newTab.id]: thumbData[thumbKey] });
            // Remove old thumbnail
            await browser.storage.local.remove(thumbKey);
            console.log(`Migrated thumbnail from tab ${oldTabId} to ${newTab.id}`);
          }
        } catch (thumbError) {
          console.error(`Failed to migrate thumbnail for tab ${oldTabId}:`, thumbError);
        }

      } catch (createError) {
        console.error(`Failed to re-create tab for ${data.url}:`, createError);
      }
    }

    // Replace old suspendedTabs with new ones (with correct tab IDs)
    suspendedTabs = newSuspendedTabs;
    saveSuspendedTabsState();

    const restoredCount = Object.keys(newSuspendedTabs).length;
    console.log(`Re-created ${restoredCount} suspended tabs from storage.`);

    if (restoredCount > 0) {
      console.log(`${restoredCount} suspended tab(s) were restored.`);
    }

  } catch (error) {
    console.error('Error recovering suspended tabs:', error);
  }
}

// --- Addon Startup Logic ---

// Listen for installation or update
browser.runtime.onInstalled.addListener(async (details) => {
  console.log(`Addon event: ${details.reason}`);

  if (details.reason === "update" || details.reason === "install") {
    console.log("Running migration...");
    await runMigration();

    // Recover any existing suspended tabs (handles both update and reload via about:debugging)
    console.log("Attempting to recover suspended tabs...");
    await recoverSuspendedTabs();
  }
  initialize();
});

// For regular browser startups (not an install/update)
browser.runtime.onStartup.addListener(() => {
  initialize();

  // Initialization handles tab state loading
});

